var en = new Array();
en['Önemli Bilgiler'] = 'Important Information';
en['Anketler'] = 'Surveys';
