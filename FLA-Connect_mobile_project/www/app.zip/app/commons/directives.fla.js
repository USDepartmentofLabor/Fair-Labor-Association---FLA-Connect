// ;
// (function () {
//   'use strict';

//   angular
//   .module('commons.directives.fla')
//   .directive('commons.directives.fla',[function() {
//     return {
//       restrict: 'A',
//       controller: 'PollPageController',
//       scope: {
//         cronosDataset : '@'
//       }
//     };
//   }])();